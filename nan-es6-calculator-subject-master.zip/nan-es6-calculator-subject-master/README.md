# nan-es6-calculator-subject
Description: Projet de prise en main du Javascript ES6

# Exercise subject

the work that you must do is to make a calculator with Javascript *(ES6 don't forget it)*. i'll tell in the next section all the features that you must integrate in your project with es6 syntax

features lists:
* addition
* multiplication
* quotient
* substraction
* square root
* valeur absolue
* manage priorities with parentheses
* 2nd f (la touche seconde fonction)
* cosinus
* sinus
* tangeante

*NB: NB: when you click on second function the quotient key becomes modulo*

i think that if you want to do javascript, you know html and css too so, i don't want a calcultor with a dirty face. do your effort to make something clean

## process for begin the exercise

1. fork the repository
2. clone the repository
3. open the nan-es6-calculator-subject folder on your computer in your code editor

GOOD LUCK !
### *Coder ? NaaaaaaaN c'est pas sorcier !*


## result

![screen shot](https://github.com/kevinvoli/nan-es6-calculator-subject/edit/master/calculator/img/Screen.png)
